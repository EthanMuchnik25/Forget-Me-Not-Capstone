# Detecting Pencils > 2024-09-25 5:16am
https://universe.roboflow.com/ethan-muchnik/detecting-pencils

Provided by a Roboflow user
License: CC BY 4.0

